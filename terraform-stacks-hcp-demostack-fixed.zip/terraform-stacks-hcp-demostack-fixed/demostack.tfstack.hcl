# demostack.tfstack.hcl
# Top-level stack definition.
# Each deployment (primary / secondary / tertiary) is declared in
# deployments.tfdeploy.hcl and supplies its own region + credentials.
# The sub-module components (vpc, networking, security, rds, compute,
# load_balancer) are declared in components.tfcomponent.hcl.

# ---------------------------------------------------------------------------
# Stack-level variables — forwarded from deployments.tfdeploy.hcl
# ---------------------------------------------------------------------------

variable "region" {
  type        = string
  description = "AWS region for this deployment."
}

variable "namespace" {
  type        = string
  description = "Unique identifier for this cluster deployment."
}

variable "identity_token" {
  type        = string
  ephemeral   = true
  description = "OIDC token for AWS workload identity."
}

variable "role_arn" {
  type        = string
  description = "IAM role ARN to assume."
}

variable "vpc_cidr_block" {
  type    = string
  default = "10.1.0.0/16"
}

variable "cidr_blocks" {
  type    = list(string)
  default = ["10.1.1.0/24", "10.1.2.0/24", "10.1.3.0/24"]
}

variable "zone_id" {
  type = string
}

variable "public_key" {
  type = string
}

variable "host_access_ip" {
  type    = list(string)
  default = []
}

variable "workers" {
  type    = string
  default = "3"
}

variable "instance_type_worker" {
  type    = string
  default = "t3.medium"
}

variable "run_nomad_jobs" {
  type    = string
  default = "0"
}

variable "cni_plugin_url" {
  type    = string
  default = "https://github.com/containernetworking/plugins/releases/download/v0.8.2/cni-plugins-linux-amd64-v0.8.2.tgz"
}

variable "enterprise" {
  type    = bool
  default = false
}

variable "nomadlicense" {
  type      = string
  sensitive = true
  default   = ""
}
